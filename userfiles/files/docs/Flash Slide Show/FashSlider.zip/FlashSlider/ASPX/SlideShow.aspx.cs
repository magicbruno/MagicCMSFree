﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.Adapters;
using System.IO;
using System.Xml;
using System.Web.UI.HtmlControls;

public partial class FlashSlider_ASPX_SlideShow : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e){
		Response.ContentType = "text/xml";
		HtmlGenericControl xmlRoot = new HtmlGenericControl("images");
		String dir = Request["dir"] + "/";
		dir = "img/";
		String myPath = Server.MapPath(dir);
		FileInfo[] files; 
		if (Directory.Exists(myPath))
		{
			DirectoryInfo dirInfo = new DirectoryInfo(myPath);
			files = dirInfo.GetFiles();
			foreach (FileInfo f in files)
			{
				HtmlGenericControl tag;
				if ((f.Extension == ".jpg") || (f.Extension == ".jpeg") || (f.Extension == ".gif") || (f.Extension == ".png") || (f.Extension == ".swf"))
				{
					tag = new HtmlGenericControl("image");
					tag.Attributes.Add("url", dir + f.Name);
					xmlRoot.Controls.Add(tag);
				}
			}
			this.Controls.Add(xmlRoot);
		}
		
    }
}